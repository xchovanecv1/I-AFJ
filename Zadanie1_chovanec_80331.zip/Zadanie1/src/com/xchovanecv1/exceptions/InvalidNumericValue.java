package com.xchovanecv1.exceptions;

public class InvalidNumericValue extends Exception{

    public InvalidNumericValue(String var) {
        super(var);
    }
}
