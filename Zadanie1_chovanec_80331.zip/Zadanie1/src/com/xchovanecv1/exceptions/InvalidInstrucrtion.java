package com.xchovanecv1.exceptions;

public class InvalidInstrucrtion extends Exception{
    public InvalidInstrucrtion(String var) {
            super(var);
        }

}
