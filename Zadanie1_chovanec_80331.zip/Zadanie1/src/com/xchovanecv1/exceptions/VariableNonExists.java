package com.xchovanecv1.exceptions;

public class VariableNonExists extends Exception{

    public VariableNonExists(String message) {
        super(message);
    }
}
