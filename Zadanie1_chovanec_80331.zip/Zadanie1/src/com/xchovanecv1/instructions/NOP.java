package com.xchovanecv1.instructions;

import com.xchovanecv1.Enviroment;

public class NOP extends Instruction {
    public NOP(String line) {
        super(line);
    }

    public void exec(Enviroment env) {
        super.exec(env);
    }
}
